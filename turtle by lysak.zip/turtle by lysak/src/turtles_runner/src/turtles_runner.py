#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose as TurtlePose
from turtlesim.srv import Spawn
import math

class TurtleRun:
    def __init__(self):
        rospy.init_node('turtles_runner')

        rospy.wait_for_service('spawn')
        spawnturtle = rospy.ServiceProxy('spawn', Spawn)
        spawnturtle(10, 10, 10, 'turtle2')

        self.turtle1_pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=1)
        self.turtle2_pub = rospy.Publisher('/turtle2/cmd_vel', Twist, queue_size=1)
        self.turtle1_sub = rospy.Subscriber('/turtle1/pose', TurtlePose, self.Leo_callback)
        self.turtle2_sub = rospy.Subscriber('/turtle2/pose', TurtlePose, self.Shreder_callback)
        
        self.rate = rospy.Rate(10)
        self.turtle1_pose = None
        self.turtle2_pose = None

    def Leo_callback(self, data):
        self.turtle1_pose = data

    def Shreder_callback(self, data):
        self.turtle2_pose = data

    def startRun(self):
        while not rospy.is_shutdown():
            if self.turtle1_pose and self.turtle2_pose:
                self.speed = rospy.get_param('~speed', 2.0)
                dx = self.turtle1_pose.x - self.turtle2_pose.x
                dy = self.turtle1_pose.y - self.turtle2_pose.y
                angle = math.atan2(dy, dx)
                distance = math.sqrt(dx ** 2 + dy ** 2)
                cmd = Twist()
                cmd.linear.x = self.speed * distance
                cmd.angular.z = 9.0 * (angle - self.turtle2_pose.theta)
                self.turtle2_pub.publish(cmd)
            self.rate.sleep()

if __name__ == '__main__':
    try:
        turtle_run = TurtleRun()
        turtle_run.startRun()
    except rospy.ROSInterruptException:
        pass
